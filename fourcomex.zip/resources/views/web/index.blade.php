@extends('layouts.main')

@section('content')
    @include('web.parts._slider')
    @include('web.parts._banner')
    @include('web.parts._products')
    @include('web.parts._markets')
    @include('web.parts._lastBlog')
@endsection