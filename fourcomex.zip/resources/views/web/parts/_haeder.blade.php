<div class="rd-navbar-middle-panel">
    <div class="rd-navbar-panel">
        <button data-rd-navbar-toggle=".rd-navbar-outer-panel" class="rd-navbar-toggle"><span></span></button>
        <a href="index.html" class="rd-navbar-brand">
            <div class="rd-navbar-fixed--hidden"><img src="{{ asset('styleWeb/images/logo.png') }}" alt="" width="250" height="40"/> </div>
        </a> </div>
    <div class="rd-navbar-aside">
        <div data-rd-navbar-toggle=".rd-navbar-aside" class="rd-navbar-aside-toggle"><span></span></div>
        <div class="rd-navbar-aside-content">
            <ul class="block-wrap-list">
                <li class="block-wrap">
                    <div class="unit unit-sm-horizontal unit-align-center unit-middle unit-spacing-xxs">
                        <div class="unit-left"><span class="icon icon-circle-sm icon-sm-variant-1 icon-venice-blue-filled icon-white mdi mdi-map-marker"></span></div>
                        <div class="unit-body">
                            <address class="contact-info">
                                <a href="#"><span>2381 Rosecrans Ave, Suite 200 El Segundo, </span><br>
                                    <span>CA 90245. USA</span></a>
                            </address>
                        </div>
                    </div>
                </li>
                <li class="block-wrap">
                    <div class="unit unit-sm-horizontal unit-align-center unit-middle unit-spacing-xxs">
                        <div class="unit-left"><span class="icon icon-circle-sm icon-sm-variant-1 icon-venice-blue-filled icon-white fa-clock-o"></span></div>
                        <div class="unit-body">
                            <address class="contact-info">
                                <span>Mon-Fri: 9:00am-6:30pm</span><span>Sat-Sun: 10:00am-6:00pm</span>
                            </address>
                        </div>
                    </div>
                </li>
                <li class="block-wrap">
                    <div class="unit unit-sm-horizontal unit-align-center unit-middle unit-spacing-xxs">
                        <div class="unit-left"><span class="icon icon-circle-sm icon-sm-variant-1 icon-venice-blue-filled icon-white mdi mdi-phone"></span></div>
                        <div class="unit-body">
                            <address class="contact-info">
                                <span><a href="callto:#">1-900-8123</a></span><span><a href="callto:#">1-900-8124</a></span>
                            </address>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</div>