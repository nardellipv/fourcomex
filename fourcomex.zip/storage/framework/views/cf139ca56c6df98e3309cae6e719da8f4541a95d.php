<section class="section-60 section-sm-110 bg-gray-lighter">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 text-center">
                <h2 style="color: #004A8C;">Latest Blog Posts</h2>
                <div class="divider divider-md divider-primary"></div>
            </div>
        </div>
        <div class="row isotope-wrap offset-top-35 offset-md-top-55">
            <div data-isotope-layout="moduloColumns" class="isotope isotope-spacing-1">
                <?php $__currentLoopData = $lastPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lastPost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-sm-6 col-lg-4 isotope-item">
                        <article class="post post-variant-1">
                            <figure class="post-image"><img src="<?php echo e($lastPost->photo); ?>" alt="" width="370" height="247"/>
                            </figure>
                            <div class="post-body">
                                <div class="post-header">
                                    <h6><a href="blog-post.html"><?php echo e($lastPost->title); ?></a></h6>
                                </div>
                                <div class="post-meta">
                                    <time datetime="2016-03-05">May 26, 2016 at 10:34 am</time>
                                </div>
                                <div class="post-text">
                                    <p><?php echo e(Str::limit($lastPost->body, 150)); ?></p>
                                </div>
                                <div class="post-footer">
                                    <ul class="list-tags-variant-1">
                                        <li><a href="#">Leer Noticia</a></li>
                                    </ul>
                                </div>
                            </div>
                        </article>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <div class="shell offset-top-30 offset-sm-top-60">
        <div class="text-center"><a href="blog-sidebar.html" class="btn btn-primary min-width-230">Ver todas nuestas noticias</a></div>
    </div>
</section><?php /**PATH D:\Webs\fourcomex\resources\views/web/parts/_lastBlog.blade.php ENDPATH**/ ?>