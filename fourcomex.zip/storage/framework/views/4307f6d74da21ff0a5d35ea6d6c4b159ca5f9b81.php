<div class="rd-navbar-outer-panel">
    <div class="rd-navbar-nav-wrap">
        <ul class="rd-navbar-nav">
            <li class="active"><a href="<?php echo e(route('home')); ?>">Inicio</a></li>
            <li><a href="#">GLP</a>
                <ul class="rd-navbar-dropdown">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($category->provider_id == 1): ?>
                            <li><a href="<?php echo e(route('provider.index', [$category->provider_id, $category->slug])); ?>"><?php echo e($category->name); ?></a></li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </li>
            <li><a href="#">Gases Industriales</a>
                <ul class="rd-navbar-dropdown">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($category->provider_id == 2): ?>
                            <li><a href="<?php echo e(route('provider.index', [$category->provider_id, $category->slug])); ?>"><?php echo e($category->name); ?></a></li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </li>
            <li><a href="#">Mezcladoras</a>
                <ul class="rd-navbar-dropdown">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($category->provider_id == 3): ?>
                            <li><a href="<?php echo e(route('provider.index', [$category->provider_id, $category->slug])); ?>"><?php echo e($category->name); ?></a></li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </li>

            
            <li><a href="#">NEWS</a>
                <ul class="rd-navbar-dropdown">
                    <li><a href="<?php echo e(route('blog.index')); ?>">Información Técnica</a></li>
                </ul>
            </li>
            <li><a href="<?php echo e(url('/sobre-nosotros')); ?>">SOBRE NOSOTROS</a></li>
            <li><a href="<?php echo e(url('/contacto')); ?>">CONTACTO</a></li>
            <li><a href="<?php echo e(url('/login')); ?>">Ingresar</a></li>
        </ul>
        
    </div>
</div><?php /**PATH D:\Webs\fourcomex\resources\views/web/parts/_menu.blade.php ENDPATH**/ ?>