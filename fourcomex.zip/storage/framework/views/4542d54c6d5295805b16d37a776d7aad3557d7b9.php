<?php $__env->startSection('style'); ?>
    <link href="<?php echo e(asset('styleAdmin/assets/plugins/fileuploads/css/dropify.min.css')); ?>" rel="stylesheet"
          type="text/css"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">

        <div class="col-md-12">
            <div class="card-box">
                <h4 class="m-t-0 header-title">Editar Categoría</h4>

                <form method="post" action="<?php echo e(route('update.category', $content)); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="nombre" class="col-form-label">Nombre</label>
                        <input type="text" class="form-control" name="name" id="nombre" placeholder="Nombre"
                               value="<?php echo e($content->name); ?>">
                    </div>

                    <div class="form-group">
                        <label>Descripción</label>
                        <textarea name="description" id="description"><?php echo e($content->description); ?></textarea>
                    </div>

                    <div class="row">
                        <div class="col-md-5">
                            <div class="form-group">
                                <label>Proveedores</label>
                                <select class="form-control select2" name="provider_id" required>
                                    <option value="<?php echo e($content->provider->id); ?>"><?php echo e($content->provider->name); ?></option>
                                    <option disabled>-------------------------</option>
                                    <?php $__currentLoopData = $providers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($provider->id); ?>"><?php echo e($provider->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="card-box">
                                <div class="form-group">
                                    <label>Imagen de la cateogría</label>
                                    <input type="file" name="photo" class="dropify"
                                           data-default-file="<?php echo e(asset('images/category/170x140-'. $content->photo)); ?>"
                                           data-max-file-size="1M" />
                                </div>
                            </div>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-info btn btn-block">Actualizar Categoría</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('styleAdmin/assets/plugins/fileuploads/js/dropify.min.js')); ?>"></script>

    <script type="text/javascript">
        $('.dropify').dropify({
            messages: {
                'default': 'Arrastre la imagen hasta el recuadro o haga click acá',
                'replace': 'Arrastre la imagen hasta el recuadro o haga click acá',
                'remove': 'Borrar',
                'error': 'Ooops, algo paso.'
            },
            error: {
                'fileSize': 'The file size is too big (1M max).'
            }
        });
    </script>

    <script src="https://cdn.ckeditor.com/4.5.6/standard/ckeditor.js"></script>

    <script>
        CKEDITOR.replace('description');
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Webs\fourcomex\resources\views/admin/parts/category/_editCategory.blade.php ENDPATH**/ ?>