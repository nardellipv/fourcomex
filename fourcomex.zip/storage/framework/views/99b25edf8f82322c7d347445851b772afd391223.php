<?php $__env->startSection('style'); ?>
    <link href="<?php echo e(asset('styleAdmin/assets/plugins/fileuploads/css/dropify.min.css')); ?>" rel="stylesheet"
          type="text/css"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-8 offset-2">
            <div class="card-box">
                <form method="post" action="<?php echo e(route('add.slider')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="texto" class="col-form-label">Texto Slider</label>
                        <input type="text" class="form-control" name="title" id="texto" placeholder="Texto">
                    </div>

                    <div class="card-box">
                        <div class="form-group">
                            <label>Imagen Slider</label>
                            <input type="file" name="photo" class="dropify"
                                   data-max-file-size="1M"/>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-info btn btn-block">Agregar Slider</button>
                </form>
            </div>
        </div>
    </div>


    <div class="row">
        <div class="col-md-10 offset-1">
            <div class="card-box">
                <table class="table">
                    <thead class="thead-light">
                    <tr>
                        <th>Imágen</th>
                        <th>Título</th>
                        <th>Acción</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th style="width: 25%;"><img src="<?php echo e(asset('images/section/118X88-'.$slider->picture)); ?>"> </th>
                            <td><?php echo e($slider->title); ?></td>
                            <td>
                                <a href="<?php echo e(route('edit.slider', $slider)); ?>"
                                   class="btn btn-icon waves-effect waves-light btn-info m-b-5"> <i
                                            class="fa fa-file-text-o"></i> </a>
                                <a href="<?php echo e(route('delete.slider', $slider)); ?>"
                                   class="btn btn-icon waves-effect waves-light btn-danger m-b-5"> <i
                                            class="fa fa-trash"></i> </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('styleAdmin/assets/plugins/fileuploads/js/dropify.min.js')); ?>"></script>
    <script type="text/javascript">
        $('.dropify').dropify({
            messages: {
                'default': 'Arrastre la imagen hasta el recuadro o haga click acá',
                'replace': 'Arrastre la imagen hasta el recuadro o haga click acá',
                'remove': 'Borrar',
                'error': 'Ooops, algo paso.'
            },
            error: {
                'fileSize': 'The file size is too big (1M max).'
            }
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Webs\fourcomex\resources\views/admin/parts/section/_sliderView.blade.php ENDPATH**/ ?>