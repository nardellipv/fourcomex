<?php $__env->startSection('content'); ?>
    <section class="section-60 section-sm-top-90 section-sm-bottom-110">
        <div class="shell">
            <div class="range">
                <div class="cell-md-8">
                    <ul class="blog-modern">
                        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="post-wrap">
                                <div class="post-wrap-header">
                                    <article class="post-wrap-meta">
                                        <time datetime="2016-05-06"><?php echo e($post->created_at->format('d-M')); ?></time>
                                        <figure><img src="images/80x80.jpg" alt="" width="80" height="80"/></figure>
                                        <div class="link"><a href="#"><?php echo e($post->user->name); ?></a></div>
                                    </article>
                                </div>
                                <div class="post-wrap-body">
                                    <article class="post post-variant-4">
                                        <figure class="post-image"><img src="<?php echo e($post->photo); ?>" alt="" width="570"
                                                                        height="378"/></figure>
                                        <div class="post-body">
                                            <div class="post-header">
                                                <h6><a href="<?php echo e(route('blog.post', $post->slug)); ?>"><?php echo e($post->title); ?></a></h6>
                                            </div>
                                            <div class="post-text">
                                                <p><?php echo Str::limit($post->body, 150); ?></p>
                                            </div>
                                            <div class="post-footer">
                                                <ul class="list-tags-variant-1">
                                                    <li><a href="<?php echo e(route('blog.post', $post->slug)); ?>">Continuar Leyendo</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </article>
                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <div class="offset-top-35 offset-sm-top-60">
                        <?php echo e($posts->render()); ?>

                    </div>
                </div>
                <?php echo $__env->make('web.parts.blog._asideBlog', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Webs\fourcomex\resources\views/web/parts/blog/_index.blade.php ENDPATH**/ ?>