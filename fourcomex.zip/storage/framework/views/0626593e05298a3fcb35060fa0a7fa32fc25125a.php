<?php $__env->startSection('style'); ?>
    <link href="<?php echo e(asset('styleAdmin/assets/plugins/fileuploads/css/dropify.min.css')); ?>" rel="stylesheet"
          type="text/css"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-8 offset-2">
            <div class="card-box">
                <form method="post" action="<?php echo e(route('add.about')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="title" class="col-form-label">Título</label>
                        <input type="text" class="form-control" name="title" id="title"
                               placeholder="Título Sobre Nosotros">
                    </div>

                    <div class="form-group">
                        <label>Texto</label>
                        <textarea name="text" id="description"></textarea>
                    </div>

                    <div class="card-box">
                        <div class="form-group">
                            <label>Imagen</label>
                            <input type="file" name="photo" class="dropify"
                                   data-max-file-size="1M"/>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-info btn btn-block">Agregar descripción</button>
                </form>
            </div>
        </div>
    </div>


    <div class="row">
        <div class="col-md-10 offset-1">
            <div class="card-box">
                <table class="table">
                    <thead class="thead-light">
                    <tr>
                        <th>Imágen</th>
                        <th>Título</th>
                        <th>Texto</th>
                        <th>Accion</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $views; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $view): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th style="width: 30%"><img src="<?php echo e(asset('images/section/600x316-' .$view->picture)); ?>" width="85%"> </th>
                            <td><?php echo e($view->title); ?></td>
                            <td><?php echo Str::limit($view->text, 30); ?></td>
                            <td>
                                <a href="<?php echo e(route('edit.about', $view)); ?>"
                                   class="btn btn-icon waves-effect waves-light btn-info m-b-5"> <i
                                            class="fa fa-file-text-o"></i> </a>
                                <a href="<?php echo e(route('delete.about', $view)); ?>"
                                   class="btn btn-icon waves-effect waves-light btn-danger m-b-5"> <i
                                            class="fa fa-trash"></i> </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('styleAdmin/assets/plugins/fileuploads/js/dropify.min.js')); ?>"></script>
    <script type="text/javascript">
        $('.dropify').dropify({
            messages: {
                'default': 'Arrastre la imagen hasta el recuadro o haga click acá',
                'replace': 'Arrastre la imagen hasta el recuadro o haga click acá',
                'remove': 'Borrar',
                'error': 'Ooops, algo paso.'
            },
            error: {
                'fileSize': 'The file size is too big (1M max).'
            }
        });
    </script>

    <script src="https://cdn.ckeditor.com/4.5.6/standard/ckeditor.js"></script>

    <script>
        CKEDITOR.replace('description');
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Webs\fourcomex\resources\views/admin/parts/section/_aboutView.blade.php ENDPATH**/ ?>