<section class="section-top-60 section-sm-top-90">
    <div class="container">
        <div class="row grid-system-row offset-top-32">
            <div class="col-xs-6">
                    <h2 style="color: #004A8C;">Do you need tablet repair service?</h2>
                    <p style="font: bold">Do you need tablet repair service? Its easy to fall in love with your tablet, as it offers the perfect combination of size and function. Whether you use it for work, school, or play, your tablet is a handy companion that is easy to take with you. If this convenience has been interrupted by damage or malfunction, we can fix the problem quickly so that you can enjoy your tablet again.</p>
            </div>
            <div class="col-xs-6">
                    <img src="<?php echo e(asset('styleWeb/images/img-home/card-lgld2-4.jpg')); ?>">
            </div>
        </div>
    </div>
</section><?php /**PATH D:\Webs\fourcomex\resources\views/web/parts/_banner.blade.php ENDPATH**/ ?>