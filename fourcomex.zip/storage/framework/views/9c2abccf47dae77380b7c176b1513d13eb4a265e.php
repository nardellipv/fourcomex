<div class="cell-md-4 offset-top-88 offset-md-top-0">
    <div class="range">
        <div class="cell-sm-6 cell-md-12 aside-list-group">
            <div class="list-item">
                <h5>Últimas Noticias</h5>
                <hr>
                <ul class="post-list offset-top-22">
                    <?php $__currentLoopData = $lastPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lastPost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <article class="post-recent">
                                <div class="post-header">
                                    <h6><a href="<?php echo e(route('blog.post', $lastPost->slug)); ?>"><?php echo e($lastPost->title); ?></a></h6>
                                </div>
                                <div class="post-meta"></div>
                                <time datetime="2016-05-28"><?php echo e($lastPost->created_at->format('d-m-Y')); ?></time>
                            </article>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    </div>
</div><?php /**PATH D:\Webs\fourcomex\resources\views/web/parts/blog/_asideBlog.blade.php ENDPATH**/ ?>