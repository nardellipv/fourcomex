<div class="swiper-wrapper">
    <div data-autoplay="false" data-slide-effect="fade" class="swiper-container swiper-slider">
        <div class="swiper-wrapper">
            <div class="swiper-slide"><img src="<?php echo e(asset('styleWeb/images/truck.jpg')); ?>" alt="" width="1920" height="600"/>
                <div class="swiper-slide-caption">
                    <div class="shell text-center text-sm-left">
                        <div class="range">
                            <div class="cell-sm-8 cell-md-8 cell-lg-9">
                                <h1><br class="veil reveal-sm-block">
                                    WE CAN DO ANYTHING!</h1>
                                <div class="swiper-slide-text">
                                    <h5 class="text-style-1">Industry Leader for Over 60 Years.</h5>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="swiper-slide"><img src="<?php echo e(asset('styleWeb/images/truck.jpg')); ?>" alt="" width="1920" height="600"/>
                <div class="swiper-slide-caption">
                    <div class="shell text-center text-sm-left">
                        <div class="range">
                            <div class="cell-sm-8 cell-md-8 cell-lg-6">
                                <h1> PROFESSIONAL REPAIR SERVICES</h1>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="swiper-slide"><img src="<?php echo e(asset('styleWeb/images/truck.jpg')); ?>" alt="" width="1920" height="600"/>
                <div class="swiper-slide-caption">
                    <div class="shell text-center text-sm-left">
                        <div class="range">
                            <div class="cell-sm-8 cell-md-8 cell-lg-7">
                                <h1> WE CAN DO ANYTHING!</h1>
                                <div class="swiper-slide-text">
                                    <h5 class="text-style-1"> We offer the best repair service for all kinds. </h5>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="swiper-pagination-wrap">
            <div class="shell">
                <div class="swiper-pagination"></div>
            </div>
        </div>
    </div>
</div><?php /**PATH D:\Webs\fourcomex\resources\views/web/parts/_slider.blade.php ENDPATH**/ ?>