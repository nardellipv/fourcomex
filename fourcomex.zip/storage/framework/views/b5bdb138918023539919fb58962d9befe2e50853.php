<div class="swiper-wrapper">
    <div class="swiper-slide"><img src="<?php echo e(asset('styleWeb/images/truck.jpg')); ?>" alt="" width="1920" height="600"/>
        <div class="swiper-slide-caption">
            <div class="shell text-center text-sm-left">
                <div class="range">
                    <div class="cell-sm-12">
                        <h1 style="padding: 40px 0% 31px 24%;">
                            WE CAN DO ANYTHING!</h1>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH D:\Webs\fourcomex\resources\views/web/parts/_slider.blade.php ENDPATH**/ ?>