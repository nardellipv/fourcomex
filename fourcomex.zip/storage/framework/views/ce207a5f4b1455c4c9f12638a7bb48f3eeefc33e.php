<?php $__env->startSection('content'); ?>
    <section class="section-60 section-sm-90">
        <div class="shell">
            <div class="range">
                <div class="cell-md-8">
                    <article class="post-single">
                        <div class="post-header">
                            <h4><?php echo e($post->title); ?></h4>
                        </div>
                        <div class="post-meta">
                            <time datetime="2016-05-26"><?php echo e($post->created_at->format('d-m-Y')); ?></time>
                            <span>por</span><span><?php echo e($post->user->name); ?></span></div>
                        <div class="post-body">
                            <figure class="post-image"><img src="<?php echo e($post->photo); ?>" alt="" width="770" height="510"/>
                            </figure>
                            <div class="post-text">
                                <p><?php echo $post->body; ?></p>
                            </div>
                        </div>
                    </article>
                </div>
                <?php echo $__env->make('web.parts.blog._asideBlog', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Webs\fourcomex\resources\views/web/parts/blog/_post.blade.php ENDPATH**/ ?>