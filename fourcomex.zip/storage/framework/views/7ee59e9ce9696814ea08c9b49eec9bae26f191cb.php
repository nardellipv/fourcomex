<?php $__env->startSection('style'); ?>
    <!-- DataTables -->
    <link href="<?php echo e(asset('styleAdmin/assets/plugins/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet"
          type="text/css"/>
    <link href="<?php echo e(asset('styleAdmin/assets/plugins/datatables/buttons.bootstrap4.min.css')); ?>" rel="stylesheet"
          type="text/css"/>
    <!-- Responsive datatable examples -->
    <link href="<?php echo e(asset('styleAdmin/assets/plugins/datatables/responsive.bootstrap4.min.css')); ?>" rel="stylesheet"
          type="text/css"/>
    <!-- Multi Item Selection examples -->
    <link href="<?php echo e(asset('styleAdmin/assets/plugins/datatables/select.bootstrap4.min.css')); ?>" rel="stylesheet"
          type="text/css"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card-box table-responsive">
                <h4 class="m-t-0 header-title">Listado de noticias</h4>
                <p class="text-muted font-14 m-b-30">
                    Listado de noticias dentro del blog
                </p>

                <table id="datatable" class="table table-bordered">
                    <thead>
                    <tr>
                        <th>Título</th>
                        <th>Cuerpo</th>
                        <th>Estado</th>
                        <th>Fecha publicacón</th>
                        <th>Acción</th>
                    </tr>
                    </thead>


                    <tbody>
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($post->title); ?></td>
                            <td><?php echo Str::limit($post->body, 75); ?></td>
                            <?php if($post->status == 'ACTIVE'): ?>
                                <td><span class="badge badge-success"><?php echo e($post->status); ?></span></td>
                            <?php else: ?>
                                <td><span class="badge badge-danger"><?php echo e($post->status); ?></span></td>
                            <?php endif; ?>
                            <td><?php echo e($post->created_at->format('d/m/Y')); ?></td>
                            <td>
                                <div class="btn-group btn-group-justified m-b-10">
                                    <a href="<?php echo e(route('edit.news', $post)); ?>" class="btn btn-primary waves-effect waves-light" role="button">Editar</a>
                                    <?php if($post->status == 'ACTIVE'): ?>
                                        <a href="<?php echo e(route('desactive.news', $post)); ?>" class="btn btn-warning waves-effect waves-light" role="button">Desactivar</a>
                                    <?php else: ?>
                                        <a href="<?php echo e(route('active.news', $post)); ?>" class="btn btn-warning waves-effect waves-light" role="button">Activar</a>
                                    <?php endif; ?>
                                    <a href="<?php echo e(route('destroy.news', $post)); ?>" class="btn btn-danger waves-effect waves-light" role="button">Eliminar</a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('styleAdmin/assets/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('styleAdmin/assets/plugins/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('styleAdmin/assets/plugins/datatables/dataTables.select.min.js')); ?>"></script>

    <script type="text/javascript">
        $(document).ready(function () {

            // Default Datatable
            $('#datatable').DataTable();

            //Buttons examples
            var table = $('#datatable-buttons').DataTable({
                lengthChange: false,
                buttons: ['copy', 'excel', 'pdf']
            });

            // Key Tables

            $('#key-table').DataTable({
                keys: true
            });

            // Responsive Datatable
            $('#responsive-datatable').DataTable();

            // Multi Selection Datatable
            $('#selection-datatable').DataTable({
                select: {
                    style: 'multi'
                }
            });

            table.buttons().container()
                .appendTo('#datatable-buttons_wrapper .col-md-6:eq(0)');
        });

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Webs\fourcomex\resources\views/admin/parts/news/_list.blade.php ENDPATH**/ ?>