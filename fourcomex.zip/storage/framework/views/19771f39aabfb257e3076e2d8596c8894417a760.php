<?php $__env->startSection('style'); ?>
    <link href="<?php echo e(asset('styleAdmin/assets/plugins/fileuploads/css/dropify.min.css')); ?>" rel="stylesheet"
          type="text/css"/>
    <link href="<?php echo e(asset('styleAdmin/assets/plugins/switchery/switchery.min.css')); ?>" rel="stylesheet"/>

    <style>
        .dlk-radio input[type="radio"],
        .dlk-radio input[type="checkbox"] {
            margin-left: -99999px;
            display: none;
        }

        .dlk-radio input[type="radio"] + .fa,
        .dlk-radio input[type="checkbox"] + .fa {
            opacity: 0.15
        }

        .dlk-radio input[type="radio"]:checked + .fa,
        .dlk-radio input[type="checkbox"]:checked + .fa {
            opacity: 1
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">

        <div class="col-md-12">
            <div class="card-box">
                <?php echo $__env->make('admin.alerts.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <h4 class="m-t-0 header-title">Editar Producto</h4>

                <form method="post" action="<?php echo e(route('add.product')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="nombre" class="col-form-label">Nombre</label>
                        <input type="text" class="form-control" name="name" id="nombre" placeholder="Nombre"
                               value="<?php echo e(old('name')); ?>">
                    </div>

                    <div class="form-group">
                        <label>Descripción</label>
                        <textarea name="description" id="description"><?php echo e(old('description')); ?></textarea>
                    </div>


                    <div class="form-group row">
                        <div class="col-md-6">
                            <div class="card-box">
                                <div class="form-group">
                                    <label for="codigo" class="col-form-label">Código del Producto</label>
                                    <input type="text" class="form-control" name="cod" id="codigo"
                                           placeholder="Código Producto"
                                           value="<?php echo e(old('cod')); ?>">
                                </div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="card-box">
                                <div class="form-group">
                                    <label for="codigo" class="col-form-label">Seleccione una categoría</label>
                                    <select class="form-control" name="category_id">
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?> -
                                                (<?php echo e($category->provider->name); ?>)
                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>


                    <div class="form-group row">
                        <div class="col-md-6">
                            <div class="card-box">
                                <div class="form-group">
                                    <label for="codigo" class="col-form-label">Dirección Web del Producto</label>
                                    <input type="text" class="form-control" name="link" id="codigo"
                                           placeholder="Dirección del producto"
                                           value="<?php echo e(old('link')); ?>">
                                </div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="card-box">
                                <div class="form-group">
                                    <label for="codigo" class="col-form-label">Mostrar en la pagina
                                        Principal</label><br>
                                    <label>No </label> <input type="checkbox" data-plugin="switchery"
                                                              data-color="#ffaa00" name="available"/> <label> Sí</label>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-8 offset-2">
                        <div class="card-box">
                            <div class="form-group">
                                <label>Imagen del Producto</label>
                                <input type="file" name="photo" class="dropify"
                                       data-max-file-size="1M" />
                            </div>
                        </div>
                    </div>

                    <div class="col-md-8 offset-2">
                        <div class="card-box">
                            <div class="form-group">
                                <label>Imagen del producto en miniatura</label>
                                <input type='file' name='files[]' multiple />
                            </div>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-info btn btn-block">Agregar Producto</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('styleAdmin/assets/plugins/fileuploads/js/dropify.min.js')); ?>"></script>
    <script src="<?php echo e(asset('styleAdmin/assets/plugins/switchery/switchery.min.js')); ?>"></script>

    <script type="text/javascript">
        $('.dropify').dropify({
            messages: {
                'default': 'Arrastre la imagen hasta el recuadro o haga click acá',
                'replace': 'Arrastre la imagen hasta el recuadro o haga click acá',
                'remove': 'Borrar',
                'error': 'Ooops, algo paso.'
            },
            error: {
                'fileSize': 'The file size is too big (1M max).'
            }
        });
    </script>

    <script src="https://cdn.ckeditor.com/4.5.6/standard/ckeditor.js"></script>

    <script>
        CKEDITOR.replace('description');
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Webs\fourcomex\resources\views/admin/parts/product/_addProduct.blade.php ENDPATH**/ ?>