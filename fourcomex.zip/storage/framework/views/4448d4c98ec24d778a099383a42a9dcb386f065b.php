<div class="left side-menu">
    <div class="sidebar-inner slimscrollleft">
        <!--- Sidemenu -->
        <div id="sidebar-menu">
            <ul>
                <li class="has_sub">
                    <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-newspaper"></i> <span> News</span>
                        <i class="mdi mdi-chevron-right"></i></a>
                    <ul class="list-unstyled">
                        <li><a href="<?php echo e(route('list.news')); ?>">Listado</a></li>
                        <li><a href="<?php echo e(route('add.news')); ?>">Agregar</a></li>
                    </ul>
                </li>
                <li class="has_sub">
                    <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-barcode"></i> <span> Categorias y Productos</span>
                        <i class="mdi mdi-chevron-right"></i></a>
                    <ul class="list-unstyled">
                        <li><a href="<?php echo e(route('list.category')); ?>">Listado Categorias</a></li>
                        <li><a href="<?php echo e(route('add.category')); ?>">Agregar Categoría</a></li>
                        <li><a href="<?php echo e(route('list.product')); ?>">Listado Productos</a></li>
                        <li><a href="<?php echo e(route('add.product')); ?>">Agregar Productos</a></li>
                    </ul>
                </li>
                <li class="has_sub">
                    <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-cursor-text"></i> <span> Secciones Sitio web</span>
                        <i class="mdi mdi-chevron-right"></i></a>
                    <ul class="list-unstyled">
                        <li><a href="<?php echo e(route('slider.view')); ?>">Slider</a></li>
                        <li><a href="<?php echo e(route('view.about')); ?>">Sobre Nosotros</a></li>
                    </ul>
                </li>
                <li class="has_sub">
                    <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-account"></i> <span> Usuarios</span>
                        <i class="mdi mdi-chevron-right"></i></a>
                    <ul class="list-unstyled">
                        <li><a href="<?php echo e(route('index.users')); ?>">Listado</a></li>
                    </ul>
                </li>
                <li>
                    <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"
                       class="waves-effect"><i class="mdi mdi-exit-to-app"></i> <span> Salir </span>
                    </a>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                    </form>
                </li>
            </ul>
            <div class="clearfix"></div>
        </div>
        <!-- Sidebar -->
        <div class="clearfix"></div>
    </div>
</div><?php /**PATH D:\Webs\fourcomex\resources\views/admin/parts/_menu.blade.php ENDPATH**/ ?>