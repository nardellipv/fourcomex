<section class="section-60 section-sm-110 bg-gray-lighter">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 text-center">
                <h2 style="color: #004A8C;">BLACKMER TECHNOLOGIES</h2>
                <div class="divider divider-md divider-primary"></div>
            </div>
        </div>
        <div class="row isotope-wrap offset-top-35 offset-md-top-55">
            <div data-isotope-layout="moduloColumns" class="isotope isotope-spacing-1">
                <?php $__currentLoopData = $productsPrincipal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-sm-6 col-lg-4 isotope-item">
                        <article class="post post-variant-1">
                            <figure class="post-image"><img src="<?php echo e(asset('images/product/370x277-' .$product->photo)); ?>" alt="" />
                            </figure>
                            <div class="post-body">
                                <div class="post-header">
                                    <h6><a href="<?php echo e(route('product.item', $product->slug)); ?>"><?php echo e($product->name); ?></a></h6>
                                </div>
                                <div class="post-text">
                                    <p><?php echo Str::limit($product->description, 150); ?></p>
                                </div>
                            </div>
                        </article>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</section><?php /**PATH D:\Webs\fourcomex\resources\views/web/parts/_products.blade.php ENDPATH**/ ?>