<?php $__env->startSection('content'); ?>
    <section class="section-60 section-sm-90 section-md-110">
        <div class="shell">
            <div class="range range-sm-center">
                <div class="cell-sm-8 cell-md-6">
                    <div class="inset-md-right-30">
                        <div class="thumbnail thumbnail-video">
                            <figure><img src="<?php echo e(asset('images/section/600x316-' .$about->picture)); ?>" alt="fourcomex" /></figure>
                        </div>
                    </div>
                </div>
                <div class="cell-sm-8 cell-md-6 offset-top-45 offset-md-top-0">
                    <h2><?php echo e($about->title); ?></h2>
                    <div class="divider divider-md divider-primary divider-sm-left"></div>
                    <p class="offset-top-30 offset-md-top-55"><?php echo $about->text; ?></p>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Webs\fourcomex\resources\views/web/parts/about/_about.blade.php ENDPATH**/ ?>